package com.optum.day3sbinsurance

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class Day3sbinsuranceApplication {

	static void main(String[] args) {
		SpringApplication.run(Day3sbinsuranceApplication, args)
	}

}
