package com.optum.day3sbinsurance

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Day3sbinsuranceApplicationTests {

	@Test
	void contextLoads() {
	}

}
