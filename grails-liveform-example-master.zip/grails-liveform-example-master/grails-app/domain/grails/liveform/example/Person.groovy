package grails.liveform.example

class Person {

	String firstName
	String surName
	String address
	
    static constraints = {
    }
}
