package testapp

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
